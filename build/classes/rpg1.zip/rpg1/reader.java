package rpg1;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

interface format
{
    String CODE_DELIM = "$";
    String QUERY_DELIM = "Q=";
    String SPLIT_DELIM_1 = ";";
    String OR_CODE_DELIM = "|";
    String SPLIT_DELIM_2 = ":";
    String VAR_DELIM_1 = "<";
    String VAR_DELIM_2 = ">";
    String IGNORE_DELIM = "/";
    String FUNCTION_DELIM = "%";
}
public class reader implements format
{
    public static String fileName = "Story1.script";
    Map<String,String[]> storyFile = new HashMap<>();
    // Run stuff on initialisation
    reader()
    {
        this.storyFile = this.read(fileName);
    }
    
    Map<String, String[]> read(String name)
    {
        Map<String, String[]> script = new HashMap<>();
        try
        {
            BufferedReader file = new BufferedReader(new FileReader(name));
            String line = file.readLine();
            String[] story;
            while ( file.ready() )
            {
            
                line = line.trim();
                
                if(line.startsWith(CODE_DELIM))
                {
                    line = line.replace(CODE_DELIM, "");
                    story = new String[32];
                    String scLine;
                    int i = 0;
                    while ( !(scLine = file.readLine() ).startsWith(CODE_DELIM) )
                    {
                        story[i] = scLine;
                        i++;
                    }
                    
                    for(String code:line.split("\\"+OR_CODE_DELIM))
                    {
                        // use putIfAbsent so the earliest copy of any code will be the one used
                        script.putIfAbsent(code,story);
                    }
                    line = scLine;
                }
                else
                    line = file.readLine();
            }
        }
        catch(Exception ex)
        {
            
        }
        return script;
    }
    public String[] getScript(String code)
    {
        if(!this.storyFile.containsKey(code))
        {
            System.out.println("[ERROR]: Code not found: ("+ code + ")");
            //System.out.println(Arrays.toString(this.storyFile.keySet().toArray()));
            return null;
        }
        return this.storyFile.get(code);
    }
    
}