package rpg1;

public class Rpg1 
{
    public static int FLAG_GAME_STATUS;
    public static void main(String[] args) 
    {   
        FLAG_GAME_STATUS = 0;
        reader lookup = new reader();
        menu men = new menu();
        player ply = new player(lookup);
        //System.out.println(ply.isActionCall("%setName"));
        //lookup.readStatus("NonExistantCode");
        while(FLAG_GAME_STATUS != -1)
        {
            if(FLAG_GAME_STATUS == 0)
            {
                men.show();
                men.get();
            }
            if(FLAG_GAME_STATUS == 1)
            {
                ply.putNextStatus();
                ply.narrateNext();
                ply.respondNext();
                ply.choose();
            }
                
        }
        
    }
    
}





