package rpg1;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

interface action {
    String run();
}
interface story
{
    // Story functions
    void setGender(int genderIndex);
    void setName(String name);
    
    String setName();
    String setGender();
    String randomName();
    String randomGender();
    String endGame();
    
    String getRandomName();
    int getGender();
    
    
    // Constant lists
    String[] GENDER_TERMS_1 =
    {
        "boy",
        "girl",
        "lad"
    };
    String[] NAMES_MALE =
    {
        "John Cena",
        "Davy Jones",
        "Jean-Luc Picard",
        "Chelton Evans",
        "John Smith",
        "Nick Cage",
    };
    String[] NAMES_FEMALE =
    {
        "Jane Doe",
        "Emilia Earhart",
        "Kathryn Janeway",
        "Joan of Arc",
        "Your Mother",
        "Kate Mulgrew",
    };
}
public class player implements story
{
    
    //stuff that we need for the player
    public String status;

    public Random rngDice;
    public reader lookup;
    // List of random names to draw from
    
    Map<String,String> storyTable = new HashMap<>();
    Map<String,action> actionTable = new HashMap<>();
    Map<Integer,String[]> responseTable = new HashMap<>();
    Map<Integer,String[]> narrationTable = new HashMap<>();
    // Player class constructor
    player(reader lookup) {
        this.lookup = lookup;
        this.status = "";
        this.rngDice = new Random();
        
        this.fillTables();
        
    }
    public void fillTables()
    {
        // Add key vars to the story table
        this.storyTable.putIfAbsent("name", "child");
        this.storyTable.putIfAbsent("gender", GENDER_TERMS_1[2]);
        this.storyTable.putIfAbsent("gender_code", "" + 2);
        // Add functions to the action table
        // No idea how this works DO NOT TOUCH
        this.actionTable.putIfAbsent("end", (action) () -> endGame());
        this.actionTable.putIfAbsent("setName", (action) () -> setName());
        this.actionTable.putIfAbsent("randomName", (action) () -> randomName());
        this.actionTable.putIfAbsent("setGender", (action) () -> setGender());
        this.actionTable.putIfAbsent("randomGender", (action) () -> randomGender());
    }
    public void putNextStatus()
    {
        String[] myStatus = this.lookup.getScript(this.status);
        //System.out.print(Arrays.toString(myStatus));
        this.putStatus(myStatus);
    }
    // interpret and show input
    public void putStatus(String[] script)
    {
        // wipe the current mapping
        this.narrationTable.clear();
        this.responseTable.clear();
        //
        for(String line : script)
        {
            //if an index is null, it means we have reached the end of the array
            if(line == null)
                break;
            line = line.trim();
            // if the line is empty we don't care about it
            if(line.isEmpty())
                continue;
            if(line.startsWith(reader.QUERY_DELIM))
            {
                this.addQuery(line.replace(reader.QUERY_DELIM,""));
            }
            else
            {
                this.addResponse(line);
            }
        }
            
    }
    public void addQuery(String query)
    {
        // split the query into actor and string, remembering to ignore escaped split delims
        String[] line = query.split("(?<!"+ reader.IGNORE_DELIM +")"+ reader.SPLIT_DELIM_1);
        // make sure it is the correct length
        if(line.length != 2)
            return;
        this.narrationTable.put(this.narrationTable.size(), line);
    }
    public void addResponse(String response)
    {
        // we want to ignore decision delims preceeded by escape chars
        String[] line = response.split("(?<!"+ reader.IGNORE_DELIM +")"+ reader.SPLIT_DELIM_2);
        // we should only have 2 results if we get more play it safe and ignore this
        if(line.length != 2)
            return;
        this.responseTable.put(this.responseTable.size(), line);
    }
    public void narrateNext()
    {
        this.narrate(this.narrationTable);
    }
    public void narrate(Map<Integer,String[]> narrationTable)
    {
        for(int ind = 0;ind<narrationTable.size();ind++)
        {
           // System.out.println(narrationTable.get(ind+1));
            String actor = narrationTable.get(ind)[0];
            String line = narrationTable.get(ind)[1];
            
            actor = insertVars(actor);
            line = insertVars(line);
            
            this.talk(actor, line);
            input.request();
        }
    }
    public void respondNext()
    {
        this.respond(this.responseTable);
    }
    public void respond(Map<Integer,String[]> responseTable)
    {
        for(int ind = 0;ind<responseTable.size();ind++)
        {
            String line = responseTable.get(ind)[1];
            
            line = insertVars(line);
            
            this.ask(ind+1, line);
        }
        System.out.println();
    }
    public void choose()
    {
        if(this.responseTable.isEmpty())
        {
            System.out.println("Empty choice table, exiting to avoid infinite loop");
            System.exit(-404);
            //just in case
            return;
        }
        Integer result = input.requestChoice();
        while(!validateChoice(result-1))
        {
            System.out.println("That isn't a choice");
            result = input.requestChoice();
        }
        this.interpStringCode(this.responseTable.get(result-1)[0]);   
        
    }
    public void talk(String actor, String line)
    {
        System.out.printf("[%s]%-1s", actor,line);
    }
    public void ask(Integer index, String option )
    {
        System.out.printf("%d:%-2s\n", index, option );
    }
    
    public boolean validateChoice(int index)
    {
        if( this.responseTable.containsKey(index))
            return true;
        return false;
    }
    public void interpStringCode(String code)
    {
        
        if(this.isActionCall(code))
        {
         //   System.out.println("made call using" + code);
            code = this.makeActionCall(code);
        }
        this.status += code;
    }
    public String insertVars(String line)
    {
        String[] varList = line.split("(?<!"+ reader.IGNORE_DELIM + ")" + reader.VAR_DELIM_1 +"|(?<!" + reader.IGNORE_DELIM + ")"+ reader.VAR_DELIM_2);
        String v;
        for(int ind = 0; ind < varList.length; ind++)
        {
            if(ind%2 == 0)
                continue;
            
            v = varList[ind];
            //System.out.println(this.getVar(v));
            line = line.replaceAll("<" + v + ">", this.getVar(v));
        }
        return line;
    }
    public String getVar(String var)
    {
        if(this.storyTable.containsKey(var))
            return this.storyTable.get(var);
        return "<Null Variable Pointer("+ var +") >";
    }
    public boolean isActionCall(String code)
    {  // System.out.println(Arrays.toString(this.actionTable.keySet().toArray()));
       // System.out.printf("Call: %s\nPassed check 1: %s\nPassed check 2: %s\nCheck 2 key: %s\n", code,code.startsWith("" + reader.FUNCTION_DELIM), this.actionTable.containsKey(code.replace(""+reader.FUNCTION_DELIM,"").trim()),code.replace(""+reader.FUNCTION_DELIM,"") );
        if(code.startsWith("" + reader.FUNCTION_DELIM))
            if(this.actionTable.containsKey(code.replace(reader.FUNCTION_DELIM,"")))       
                return true;
        return false;
    }
    public String makeActionCall(String code)
    {
        String result;
        code = code.replace(reader.FUNCTION_DELIM,"");
        result = this.actionTable.get(code).run();
        return result;
    }
    // All functions below this comment are custom functions for the story to be called by the script
    
    // hard set functions here
    public void setName(String name)
    {
        this.storyTable.put("name", name);
    }
    public void setGender(int genderIndex)
    {
        this.storyTable.put("gender", GENDER_TERMS_1[genderIndex]);
        this.storyTable.put("gender_code", "" + genderIndex);
    }
    
    // action functions
    public String setName()
    {
        System.out.println("What is your name? ");
        this.setName(input.requestString());
        return "A";
    }
    public String randomName()
    {
        this.setName(getRandomName());
        return "B";
    }
    
    public String setGender()
    {
        System.out.println("What is your gender?");
        this.ask(1, "Male");
        this.ask(2, "Female");
        this.ask(3, "I'm not defined by gender");
        int result = input.requestChoice(1, 3);
        this.setGender(result -1);
        return "B";
    }
    public String randomGender()
    {
        setGender(rngDice.nextInt(2));
        return "B";
    }
    public String endGame()
    {
        Rpg1.FLAG_GAME_STATUS = 0;
        this.clear();
        this.fillTables();
        return "";
    }
    // utility functions
    public void clear()
    {
        this.status = "";
        this.storyTable.clear();
    }
    public String getRandomName()
    {
        if(this.getGender() == 2)  
            return NAMES_FEMALE[rngDice.nextInt(NAMES_FEMALE.length)];
        return NAMES_MALE[rngDice.nextInt(NAMES_MALE.length)];
    }
    public int getGender()
    {
        int code = Integer.valueOf(this.storyTable.get("gender_code"));
        return code;
    }
    
}
