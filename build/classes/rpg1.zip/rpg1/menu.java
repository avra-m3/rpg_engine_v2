/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpg1;

import java.util.HashMap;
import java.util.Map;

interface option
{
    void run();
}

public class menu 
{
    static final String STR_TITLE = "RPG 1";
    Map<String,option> menuOptions = new HashMap<>();
    menu()
    {
        menuOptions.put("New Game", (option) () -> this.optionStartGame());
        menuOptions.put("Credits", (option) () -> this.optionShowCredits());
        menuOptions.put("Quit", (option) () -> this.optionExitGame());
    }
    void show()
    {
        System.out.println("Welcome to " + menu.STR_TITLE);
        Object[] keys = this.menuOptions.keySet().toArray();
        for(int i=0; i< keys.length;i++)
        {
            this.ask(i + 1, (String) keys[i]);
        }
    }
    void get()
    {
        int result = input.requestChoice(1, this.menuOptions.size()+1);
        Object[] keys = this.menuOptions.keySet().toArray();
        this.menuOptions.get( (String) keys[result-1]).run();
    }
    void ask(int index, String option)
    {
        System.out.printf("%d:%-1s\n",index,option);
    }
    void optionStartGame()
    {
        Rpg1.FLAG_GAME_STATUS = 1;
    }
    void optionExitGame()
    {
        Rpg1.FLAG_GAME_STATUS = -1;
    }
    void optionShowCredits()
    {
        for(String str: menu.STR_CREDITS)
            System.out.println(str);
    }
    static final String[] STR_CREDITS = {
        "",
        "--------------------------------------------------------------------",
        "This game was created by Avrami Hammer and Tom Lawlor as part of the",
        "RMIT Associate degree in information technology 2016",
        "",
        "--- Credits: -------------------------------------------------------",
        "Lead Programmer: Avrami Hammer",
        "Story/Game Designer: Tom Lawlor",
        "Engine Design: Avrami Hammer",
        "Art Director: Tom Lawlor",
        "Head of fake title creation: Avrami Hammer",
        "--------------------------------------------------------------------",
        "Created in NetBeans IDE for Java"
    };
}
