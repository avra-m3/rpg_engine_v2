package rpg1;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author A
 */
public class input {
    static BufferedReader getInput= new BufferedReader(new InputStreamReader(System.in));
    void input()
    {
    }
    public static String requestString()
    {
        try
        {
            String result = getInput.readLine();
            return result;
        }
        catch(IOException ex)
        {
            System.exit(-43);
        }
        return new String();
    }
    public static void request()
    {
        try
        {
            getInput.readLine();
        }
        catch(Exception ex)
        {
            
        }
        
    }
    public static String requestString(String regex)
    {
        try
        {
            
            String result = getInput.readLine();
            while(1==1)
            {
                if(result.matches(regex))
                    return result;
                System.out.println("Sorry that is a bad answer, please try again.");
                result = getInput.readLine();
            }
        }
        catch(IOException ex)
        {
            System.exit(-43);
        }
        return new String();
    }
    public static Integer requestChoice()
    {
        System.out.println("Please choose an option:");
        try
        {
            while(true)
            {
                String result = getInput.readLine();
                if(result.trim().equals("") )
                {
                }
                else if(result.matches("\\d{" + result.length() + "}"))
                    return Integer.parseInt(result);
                System.out.println("You must enter a number");
            }
        }
        catch(IOException ex)
        {
            System.out.println(ex);
            System.exit(-300);
        }
        return -1;
    }
    public static Integer requestChoice(int lowerLimit, int upperLimit)
    {
        System.out.println("Please choose an option:");
        try
        {
            while(true)
            {
                String result = getInput.readLine();
                if(result.trim().equals("") )
                {
                }
                else if(result.matches("["+ lowerLimit + "-" + upperLimit + "]"))
                    return Integer.parseInt(result);
                System.out.println("You must enter a number between " + lowerLimit + " and " + upperLimit);
            }
        }
        catch(IOException ex)
        {
            System.out.println(ex);
            System.exit(-300);
        }
        return -1;
    }
            
}
